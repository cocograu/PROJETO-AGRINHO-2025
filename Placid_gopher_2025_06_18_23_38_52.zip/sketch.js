let sol;
let paineisSolares = []; // Array para guardar todos os painéis instalados
let energiaTotalGerada = 0;
let oportunidadesAtivadas = 0;
let medidorEnergiaX, medidorEnergiaY, medidorEnergiaLargura, medidorEnergiaAltura;

// Variáveis para as imagens (descomente e preencha com seus caminhos)
/*
let imgSol, imgPainelPequeno, imgPainelMedio, imgPainelGrande;
let imgCasa, imgEstufa, imgPredio;

function preload() {
  imgSol = loadImage('assets/sol.png');
  imgPainelPequeno = loadImage('assets/painel_pequeno.png');
  // ... carregar outras imagens
}
*/

function setup() {
  createCanvas(900, 550);
  sol = new Sol(width / 2, 100); // Sol começa no meio do topo
  frameRate(30);

  // Definir posição e tamanho do medidor de energia
  medidorEnergiaLargura = 200;
  medidorEnergiaAltura = 30;
  medidorEnergiaX = width - medidorEnergiaLargura - 20;
  medidorEnergiaY = 20;

  // Adicionar um painel solar inicial para teste
  // paineisSolares.push(new PainelSolar(150, 300, 'pequeno'));
  // paineisSolares.push(new PainelSolar(600, 200, 'medio'));
}

function draw() {
  background(135, 206, 235); // Céu azul

  // Desenhar o cenário (campo e cidade)
  desenharCenario();

  // Atualizar e desenhar o sol
  sol.atualizar();
  sol.mostrar();

  // Calcular energia total gerada pelos painéis
  let energiaAtualDosPaineis = 0;
  for (let painel of paineisSolares) {
    painel.mostrar(); // Desenha o painel
    // Energia gerada pelo painel, influenciada pela posição do sol
    energiaAtualDosPaineis += painel.gerarEnergia(sol.intensidadeLuz());
  }
  // Acumula energia ao longo do tempo (simulando consumo vs. geração)
  energiaTotalGerada += (energiaAtualDosPaineis - 0.5); // Subtrai 0.5 para simular um consumo base
  energiaTotalGerada = constrain(energiaTotalGerada, 0, 1000); // Limita a energia entre 0 e 1000

  // Desenhar o medidor de energia
  desenharMedidorEnergia();

  // Lógica para ativar oportunidades (elementos no cenário)
  ativarOportunidades();

  // Exibir pontuação/oportunidades ativadas
  fill(255);
  textSize(20);
  text("Oportunidades Ativadas: " + oportunidadesAtivadas, 20, 30);
  text("Energia Acumulada: " + floor(energiaTotalGerada) + " kWh", 20, 60);

  // --- Lógica de fim de jogo ou meta atingida ---
  if (oportunidadesAtivadas >= 5) { // Exemplo: atingir 5 oportunidades
      fill(0, 200, 0);
      textSize(48);
      textAlign(CENTER, CENTER);
      text("PARABÉNS!\nVocê Colheu Oportunidades com a Energia Solar!", width / 2, height / 2);
      noLoop();
  }
}

function mousePressed() {
  // Lógica para instalar painéis solares ao clicar
  // Exemplo: clicar em um local vazio para adicionar um painel pequeno
  let clicouEmPainelExistente = false;
  for (let painel of paineisSolares) {
      if (painel.estaClicado(mouseX, mouseY)) {
          clicouEmPainelExistente = true;
          // Talvez faça algo ao clicar em um painel já existente, tipo ver detalhes
          break;
      }
  }

  // Se não clicou em um painel existente e está dentro dos limites para colocar um novo
  if (!clicouEmPainelExistente) {
      // Você pode ter uma lógica para escolher o tipo de painel (pequeno, médio, grande)
      // Por enquanto, apenas adiciona um painel pequeno
      if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height - 50) { // Evita colocar no medidor
          paineisSolares.push(new PainelSolar(mouseX, mouseY, 'pequeno'));
          console.log("Painel solar instalado em:", mouseX, mouseY);
      }
  }
}

// --- Funções de Desenho ---
function desenharCenario() {
  // Campo (grama)
  fill(124, 252, 0); // Verde grama
  rect(0, height / 2, width, height / 2);

  // Estrada de terra no campo
  fill(139, 69, 19);
  rect(0, height / 2 + 50, width, 40);

  // Cidade (parte inferior do céu)
  fill(169, 169, 169); // Cinza cidade
  rect(width * 0.6, height / 2 - 50, width * 0.4, height / 2 + 50);

  // Desenhar alguns elementos básicos de cenário
  // Fazenda no campo
  fill(205, 133, 63); // Marrom claro para fazenda
  rect(100, height / 2 - 50, 150, 100);
  fill(100);
  triangle(100, height / 2 - 50, 175, height / 2 - 120, 250, height / 2 - 50); // Telhado

  // Prédios na cidade
  fill(105, 105, 105);
  rect(width * 0.7, height / 2 - 100, 80, 150);
  rect(width * 0.85, height / 2 - 200, 100, 250);
}

function desenharMedidorEnergia() {
  // Fundo do medidor
  fill(50);
  rect(medidorEnergiaX, medidorEnergiaY, medidorEnergiaLargura, medidorEnergiaAltura, 5);

  // Barra de energia (verde)
  let larguraAtual = map(energiaTotalGerada, 0, 1000, 0, medidorEnergiaLargura);
  fill(0, 200, 0);
  rect(medidorEnergiaX, medidorEnergiaY, larguraAtual, medidorEnergiaAltura, 5);

  // Texto
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("ENERGIA:", medidorEnergiaX - 80, medidorEnergiaY + medidorEnergiaAltura / 2);
  textAlign(RIGHT, CENTER);
  text(floor(energiaTotalGerada) + "/1000", medidorEnergiaX + medidorEnergiaLargura - 5, medidorEnergiaY + medidorEnergiaAltura / 2);
}

function ativarOportunidades() {
  // Esta função verificaria a energiaTotalGerada
  // e ativaria visualmente elementos no cenário.
  // Por exemplo:
  if (energiaTotalGerada > 100 && oportunidadesAtivadas < 1) {
    // Fazer uma luz acender em uma casa
    // oportunidadesAtivadas++;
    // console.log("Casa iluminada!");
  }
  if (energiaTotalGerada > 300 && oportunidadesAtivadas < 2) {
    // Fazer uma bomba de irrigação "ligar"
    // oportunidadesAtivadas++;
    // console.log("Irrigação ativada!");
  }
  // Adicione mais condições para mais oportunidades
}


// --- Classes dos Elementos ---

class Sol {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.raio = 50;
    this.angulo = PI; // Começa no "meio do dia" simulado
    this.velocidadeAngulo = 0.005; // Velocidade do movimento do sol
  }

  atualizar() {
    this.angulo += this.velocidadeAngulo;
    // Simula o sol se movendo no céu em um arco
    this.x = width / 2 + cos(this.angulo) * (width / 2 - this.raio);
    this.y = map(sin(this.angulo), -1, 1, height * 0.1, height * 0.4); // Altura do sol

    // Reinicia o ciclo do dia quando o sol "se põe" completamente
    if (this.angulo > TWO_PI) {
        this.angulo = 0; // Reinicia o dia
        // Poderia ter uma lógica aqui para um novo "dia" no jogo
    }
  }

  mostrar() {
    fill(255, 200, 0); // Cor do sol (amarelo alaranjado)
    ellipse(this.x, this.y, this.raio * 2);
    // if(imgSol) image(imgSol, this.x - this.raio, this.y - this.raio, this.raio * 2, this.raio * 2);
  }

  // Retorna um valor de intensidade da luz (0 a 1) baseado na posição do sol
  intensidadeLuz() {
      // Mais intenso quando o sol está mais alto
      return map(this.y, height * 0.4, height * 0.1, 0, 1);
  }
}

class PainelSolar {
  constructor(x, y, tipo) {
    this.x = x;
    this.y = y;
    this.tipo = tipo; // 'pequeno', 'medio', 'grande'
    this.largura, this.altura, this.geracaoBase;

    // Define propriedades baseadas no tipo de painel
    if (this.tipo === 'pequeno') {
      this.largura = 40;
      this.altura = 30;
      this.geracaoBase = 0.5; // KWh por frame
    } else if (this.tipo === 'medio') {
      this.largura = 80;
      this.altura = 60;
      this.geracaoBase = 1.5;
    } else if (this.tipo === 'grande') {
      this.largura = 150;
      this.altura = 100;
      this.geracaoBase = 5.0;
    }
  }

  mostrar() {
    fill(50, 50, 150); // Cor dos painéis (azul escuro)
    rect(this.x, this.y, this.largura, this.altura, 5); // Retângulo arredondado
    // if(this.tipo === 'pequeno' && imgPainelPequeno) image(imgPainelPequeno, this.x, this.y, this.largura, this.altura);
    // else if (this.tipo === 'medio' && imgPainelMedio) image(imgPainelMedio, this.x, this.y, this.largura, this.altura);
    // else if (this.tipo === 'grande' && imgPainelGrande) image(imgPainelGrande, this.x, this.y, this.largura, this.altura);
  }

  gerarEnergia(intensidadeDoSol) {
    // Gera energia baseada na sua capacidade e na intensidade do sol
    return this.geracaoBase * intensidadeDoSol;
  }

  estaClicado(mx, my) {
    return mx > this.x && mx < this.x + this.largura && my > this.y && my < this.y + this.altura;
  }
}
